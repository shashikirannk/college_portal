<div class="container-fluid">
	<div class="row">
		<nav class="navbar navbar-inverse">
			<div  class="navbar-header">
						<a href="home.php" class="navbar-brand"> <img src="../img/logo.png" alt="geck logo"  height="30px"> </a>		
						<button type="button" data-toggle="collapse" class="navbar-toggle" data-target="#menu">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>					
					</div>			
					
	
			
				<div class="collapse navbar-collapse" id="menu">
					<ul class="nav navbar-nav">
						
							
						<li><a href="contact.php">Contact Us</a></li>
						
						<li><a href="facaulty.php">Faucaulty</a></li>
						
						<li><a href="event.php">Events</a></li>

						<li><a href="logout.php">Logout</a></li>

					</ul> 
					 </div>
						

					
				</div>
				</nav>
					</div>
			</div>
		
