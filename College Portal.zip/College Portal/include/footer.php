
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-12">
			<div class="foot">
			<nav class="navbar">
				<div class="col-sm-4">
					<p> <b style="color:white;">Address:	</b>	<br/> <br/> State Highway 7, Nearby TB circle Mysore,
				<br/>Channarayapatna road, Krishnarajpete,<br/> Karnataka- 571426</p>	
				</div>
				
					<div class="col-sm-4">
						<a href="https://www.google.com/maps/place/Government+Engineering+College,+K+R+Pet/@12.6582433,76.4837,17z/data=!3m1!4b1!4m5!3m4!1s0x3baf886eae7c2bc1:0xc99b36358a5dab04!8m2!3d12.6582381!4d76.4858887"
						target="_blank">
						<img src="img/map.png" alt="geck map" width="100%"/>
					</div>
					
					<div class="col-sm-4">
						<li><a href="contact.php">Contact Us</a></li>
						
					</div>
			</nav>
			</div>
		</div>
	</div>
</div>
	