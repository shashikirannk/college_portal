 <?php
 
$host="localhost";
$user="root";
$pass="";
$db="geck";

$con=mysqli_connect($host,$user,$pass,$db);



?> 