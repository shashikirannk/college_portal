<!doctype html>
<html >
<head>

    <title>GECK </title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

<!-- style by me -->
	<link rel="stylesheet" href="./include/style.css" />


	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</head>
<style>
	
.ab{
	background-color: black;
}

.ef{
	color: green;
}

 




</style>
</head>
	
<body>


<?php include "include/header.php"; ?>


<div class="container">
	<div class="row">
		<div class="col-sm-8 kannada">
			<hr/>
			<p><b> <br/>
				2007 ರಲ್ಲಿ ಪ್ರಾರಂಭವಾದ ಸರ್ಕಾರಿ ಇಂಜಿನಿಯರಿಂಗ್ ಕಾಲೇಜ್, ಕೆ.ಆರ್. ಪೆಟ್ (ವಿ.ಟಿ.ಯು ಕೋಡ್: 4 ಜಿಕೆ), ವಿಶ್ವೇಶ್ವರಯ್ಯ ಟೆಕ್ನಾಲಜಿಕಲ್ ಯುನಿವರ್ಸಿಟಿ, ಬೆಳಗಾಮ್ ಮತ್ತು ಎಐಸಿಸಿಟಿ, ನವ ದೆಹಲಿಯಿಂದ ಅಂಗೀಕರಿಸಲ್ಪಟ್ಟಿದೆ.  
				  2007-08ರ ಅವಧಿಯಲ್ಲಿ ಕರ್ನಾಟಕ ಸರ್ಕಾರಿ ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ ಅಡಿಯಲ್ಲಿ 10 ಎಂಜಿನಿಯರಿಂಗ್ ಕಾಲೇಜುಗಳನ್ನು ಸ್ಥಾಪಿಸಿದೆ. ಜಿಇಸಿ ಆರ್ ಆರ್ ಪೆಟ್ ಎಂಬುದು ಇಂಜಿನಿಯರಿಂಗ್ನ ನಾಲ್ಕು ಶಾಖೆಗಳು, 
				ಸಿವಿಲ್ ಇಂಜಿನಿಯರಿಂಗ್, ಕಂಪ್ಯೂಟರ್ ಸೈನ್ಸ್ & ಎಂಜಿನಿಯರಿಂಗ್, ಎಲೆಕ್ಟ್ರಾನಿಕ್ಸ್ ಮತ್ತು ಕಮ್ಯುನಿಕೇಷನ್ ಎಂಜಿನಿಯರಿಂಗ್ ಮತ್ತು ಮೆಕ್ಯಾನಿಕಲ್ ಇಂಜಿನಿಯರಿಂಗ್ ಸಂಸ್ಥೆಗಳೊಂದಿಗೆ ಸ್ಥಾಪಿಸಲ್ಪಟ್ಟ ಒಂದು ಕಾಲೇಜು.
			</b> </p>
		</div>

		<div class="col-sm-4">
			<hr/>
			<div class="panel panel-primary">
				<div class="panel-heading">
					GECK BRANCHES
				</div>

				<div class="ef">
					<form >
						<marquee direction="up">
							<ul> 
								<li> COMPUTER SCIENCE </li><br/><br/>
								<li> CIVIL</li>				<br/><br/>
								<li> ELECTRONICS</li>		<br/><br/>
								<li> MECHANICAL </li>
							</ul>
						</marquee> 
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<?php include "include/footer.php"; ?>
	
	
</body>
</html>